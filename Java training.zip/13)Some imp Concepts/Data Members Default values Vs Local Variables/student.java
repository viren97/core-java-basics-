class student
{
	void display()
	{
		int a;
		System.out.println(a);
	}
	
	
public static void main(String args[])
	{
      student t=new student();
	  t.display();
	}

}
/*
	The Program segment will generate a compilation error
	"variable <variable name> might not have been initialized"
*/
	
	
	
	
	
